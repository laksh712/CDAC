#include "animals.h"
/*
const char* Animals::getName() const {
    return "";
}
*/

const char* Lion::getName() const {
    return "Lion";
}

const char* Rat::getName() const {
    return "Rat";
}