import './Header.css';
const Header=()=>{
    return(
        <h1 className="myclass">Counter component demo</h1>
    )
}
export default Header;