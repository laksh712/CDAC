const Header=(props)=>{
   return <h1>This is header {props.name}  {props.mobile}</h1>
}
export const F1=()=>{
     return <h2>this is f1</h2>
}
export default Header;