const m2=require("./module2");
var n=m2.combination(5,4);
console.log("combination : "+n);
console.log(m2.user.uid);