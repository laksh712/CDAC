const m1=require("./module1");
console.log("Addition: "+m1.addition(20,30));
console.log("Factorial: "+m1.factorial(5));

