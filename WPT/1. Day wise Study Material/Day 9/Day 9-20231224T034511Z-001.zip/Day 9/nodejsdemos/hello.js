function add(x,y){
    x=x+10;
    y=y+20;
    return x+y;
}
console.log("hello world!!");
console.error("this is error message!!")
console.log("Addition :"+add(10,20));