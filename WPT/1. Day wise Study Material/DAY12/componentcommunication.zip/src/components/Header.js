import './Header.css';
const Header=()=>{
    return(
        <h1 className="myclass">Component Communication demo</h1>
    )
}
export default Header;