package sets2;

public class TestMe {

	public static void main(String[] args) {
		// BBBB AaBB AaAa BBAa
		System.out.println("BBBB".equals("AaBB"));
		System.out.println("BBBB".equals("AaAa"));
		System.out.println("BBBB".equals("BBAa"));
		System.out.println("BBBB".hashCode());
		System.out.println("AaBB".hashCode());
		System.out.println("AaAa".hashCode());
		System.out.println("AaAa".hashCode());
		

	}

}
