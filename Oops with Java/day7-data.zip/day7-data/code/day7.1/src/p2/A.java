package p2;

public interface A {
	int DATA = 12345;//public static final
	double calculate(double d1,double d2);//public abstract
}
