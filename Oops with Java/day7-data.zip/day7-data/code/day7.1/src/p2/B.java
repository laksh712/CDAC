package p2;

public interface B {
	int DATA = 2345;//public static final
	double calculate(double d1,double d2);//public abstract
}
