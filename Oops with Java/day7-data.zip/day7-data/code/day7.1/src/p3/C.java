package p3;

public interface C extends A,B{
	double calculate(double d1,double d2);
}
