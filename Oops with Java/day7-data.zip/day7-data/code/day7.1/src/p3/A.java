package p3;

public interface A {
	void show();
	boolean isEven(int no);
}
