package p3;

public interface B {
	void print(String mesg);
	int compare(int no1,int no2);
}
