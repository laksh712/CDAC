package p3;

/*
 * The concrete implementation class MUST imple : all inherited 
 * abstract methods
 */
public class D implements C {

	@Override
	public void print(String mesg) {
		// TODO Auto-generated method stub

	}

	@Override
	public int compare(int no1, int no2) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public void show() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean isEven(int no) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public double calculate(double d1, double d2) {
		// TODO Auto-generated method stub
		return 0;
	}

}
