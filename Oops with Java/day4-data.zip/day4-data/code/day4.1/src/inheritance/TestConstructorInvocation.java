package inheritance;

public class TestConstructorInvocation {

	public static void main(String[] args) {
		C c1=new C();

	}

}
